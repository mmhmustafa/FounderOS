# BUILD_ROADMAP

## Milestone 1 - Repository Reconciliation

- [x] Repository scaffold
- [x] Official `.ai/` governance location
- [x] Architecture Specification v1.0-alpha
- [x] Initial state catalogue
- [x] Thin Master Orchestrator specification
- [x] Honest status labels for planned placeholders

## Milestone 2 - Executable Runtime Contracts

- [x] Define canonical identifiers and versioning
- [x] Define machine-valid core-object schemas
- [x] Define Project, workflow-run, agent-run, transition, evaluation, approval, and event records
- [x] Define state-transition guards and recovery behavior
- [x] Define persistence and state-mutation boundaries
- [x] Define contract-level acceptance scenarios
- [x] Replace runtime placeholders with contract-level component specifications

## Milestone 3 - Runtime Foundation

- [x] Minimal Python package and dependency baseline
- [x] Contract loading and JSON Schema validation
- [x] In-memory repositories for required runtime records
- [x] Project State with optimistic revisions
- [x] Guarded State Machine transitions
- [x] Ordered Event append and Project replay
- [x] Basic WorkflowRun and AgentRun lifecycles
- [x] Automated contract acceptance scenarios

## Milestone 4 - Runtime Planner Engine

- [x] Immutable ExecutionContext
- [x] Immutable ExecutionPlan
- [x] State-aware WorkflowSelector
- [x] Approved-artifact gap analysis
- [x] Deterministic AgentRouter
- [x] State Machine route and quality-gate integration
- [x] Explicit blocking reasons and unknown-state rejection
- [x] Non-mutation and determinism tests

## Milestone 5 - First Executable Vertical Slice

- [x] Create or resume a project in the active runtime
- [x] Produce, validate, persist, and approve a structured Founder Brief
- [x] Persist run, evaluation, approval, event, artifact, and transition records in memory
- [x] Verify deterministic replay/resume behavior and idempotent completion

## Milestone 6 - FounderOS CLI

- [x] Add thin standard-library command parsing
- [x] Add `new`, `status`, `plan`, `founder-brief`, `approve`, `decisions`, and `events`
- [x] Persist one local Project as JSON, JSONL Events, and Artifact JSON files
- [x] Reload and validate runtime records across CLI invocations
- [x] Preserve Planner, Approval, and State Machine boundaries
- [x] Add CLI acceptance coverage

## Milestone 7 - Persistence Hardening

- [x] Add exclusive single-writer protection
- [x] Reject stale writes using monotonic store revisions
- [x] Create a validated backup before replacing committed files
- [x] Detect corrupt/missing state, Event errors, replay mismatch, and Artifact digest mismatch
- [x] Add explicit backup recovery and persistence health reporting
- [x] Add format-version migration structure and future-version rejection
- [x] Add corruption, locking, stale-write, migration, and recovery tests

## Milestone 8 - Runtime Service Boundary Hardening

- [x] Replace persistence hydration through repository internals with explicit import/export ports
- [x] Extract Artifact, Evaluation, and Approval lifecycle operations from the Founder Setup coordinator
- [x] Retain WorkflowRun and AgentRun services as reusable lifecycle boundaries
- [x] Persist command idempotency keys independently of in-process service instances
- [x] Define stale-lock inspection and guarded manual lock removal
- [x] Add failure-injection coverage across multi-file save phases

## Milestone 9 - Runtime Observability and Audit Diagnostics

- [x] Define structured runtime diagnostic summaries without adding a database
- [x] Add command correlation and operation timing summaries
- [x] Add inspectable run, transition, approval, Artifact, and persistence diagnostics
- [x] Add default redaction and explicit sensitive-content opt-in
- [x] Add end-to-end audit consistency checks
- [x] Add read-only audit, runs, and transitions CLI commands

## Milestone 10 - Discovery Workflow v1

- [x] Add deterministic Discovery service and static candidate input
- [x] Define Opportunity Report and Candidate contracts
- [x] Compute and rank six-factor scores deterministically
- [x] Persist runs, Artifact, Evaluation, Approval, and selection Decision
- [x] Apply guarded transitions through `DISCOVERY_RUNNING` to `OPPORTUNITY_SELECTED`
- [x] Add CLI, audit traceability, replay, and acceptance tests

## Milestone 11 - Developer Experience and Test Stability

- [x] Diagnose Windows pytest completion behavior
- [x] Diagnose and repair invalid Windows ACLs on pytest's standard cache path
- [x] Add official PowerShell and POSIX test scripts
- [x] Define pytest as an installable development dependency
- [x] Document editable setup, test commands, and Windows troubleshooting
- [x] Preserve runtime and CLI behavior while verifying the full suite

### Milestone 11.1 - Developer Experience Bug Fix

- [x] Reproduce pytest cache access under the exact quiet command
- [x] Prove no runtime thread, subprocess, lock, or cleanup leak exists
- [x] Identify the protected non-inheriting `.pytest_cache` ACL
- [x] Restore inherited workspace permissions
- [x] Remove the alternate cache-directory workaround
- [x] Verify warning-free normal process termination

### Milestone 11.2 - Windows Stale-Lock Probe Fix

- [x] Isolate the hanging service-boundary lock test
- [x] Remove POSIX signal probing from the Windows runtime path
- [x] Use non-signalling Win32 process inspection with deterministic handle cleanup
- [x] Add Windows-specific regression coverage
- [x] Verify the service-boundary file and full suite terminate normally

## Milestone 12A - FounderOS v0.2 Architecture Review Board

- [x] Review the draft v0.2 Blueprint from enterprise, distributed systems, AI, software, and startup perspectives
- [x] Identify conflicting App/Workflow semantics and missing trust/execution boundaries
- [x] Recommend a narrower vertical-slice-driven v0.2 scope
- [x] Record conditional approval: proceed with changes

## Milestone 12B - Blueprint Revision and Architecture Decisions

- [x] Define App as a package and Workflow as the executable unit
- [x] Establish a modular-monolith dependency model with outbound ports
- [x] Preserve the Kernel and State Machine as sole domain/state mutation authorities
- [x] Define lifecycle versus utility Workflows
- [x] Define first-party App package contents and compatibility direction
- [x] Narrow v0.2 scope and explicit non-goals
- [x] Establish authorization, durable activity, package, fake-provider, and Validation implementation gates

## Milestone 12C - Authorization Policy Foundation

- [x] Define Actor, Action, Resource, Effect, Condition, Policy, and Decision concepts
- [x] Define placeholder AuthorizationRequest, AuthorizationDecision, PolicyRule, AuthorizationPolicy, and PolicyEngine contracts
- [x] Define deterministic default-deny and deny-overrides evaluation
- [x] Reserve authorization checks before every owning Kernel mutation boundary
- [x] Separate authorization from authentication, RBAC, and human Approval
- [x] Add redaction, future enterprise compatibility, diagrams, and an authorization ADR
- [x] Preserve runtime behavior by keeping contracts outside the active ContractRegistry

## Milestone 12D - Durable Activity and Side-Effect Contracts

- [x] Define Activity, Request, Result, Record, category, status, attempt, and policy concepts
- [x] Define retry, timeout, cancellation, compensation, lease, receipt, and failure semantics
- [x] Define stable idempotency, replay, ambiguous-outcome, and reconciliation rules
- [x] Define ActivityExecutor, ActivityRegistry, ActivityService, policy evaluator, and audit reader placeholder interfaces
- [x] Define Activity audit Events, correlation, redaction, and observability
- [x] Add RFC-0001, placeholder Draft 2020-12 contracts, and ADR-002
- [x] Keep executors, Providers, Tools, queues, workers, and runtime behavior out of scope

Authorization runtime enforcement remains mandatory before Provider or Tool execution. Milestone 12C defines the boundary but intentionally does not wire it into current services.

## Milestone 12E - Minimal First-Party App Package Contract (Deferred)

- [ ] Define package identity, Kernel compatibility, asset index, configuration, and historical resolution
- [ ] Reuse existing Agent and Workflow definitions and registries
- [ ] Define lifecycle versus utility Workflow contract extensions only as required

## Milestone 12F - Fake Structured-Generation Provider

- [ ] Define canonical structured generation requests/results, budgets, and typed failures
- [ ] Add versioned prompt rendering and deterministic fake behavior
- [ ] Keep real Provider integration out of scope

## Milestone 12G - Validation App Vertical Slice

- [ ] Package Validation as the first bundled first-party App
- [ ] Reuse Kernel Artifact, Evaluation, Approval, Decision, Transition, Event, replay, and audit boundaries
- [ ] Demonstrate value from `OPPORTUNITY_SELECTED` without Web, marketplace, broad Tools, or real Providers

## FounderOS v0.3 Contract Foundations

### PR-001 - Agent Manifest Schema Foundation

- [x] Add a strict, versioned Agent Manifest schema outside the active runtime loader
- [x] Add a valid Product Manager example
- [x] Define status, maturity, capabilities, Artifact ports, constraints, Tool categories, Provider-neutral preferences, Evaluation, and handoff metadata
- [x] Prohibit prompts, secrets, model configuration, runtime state, memory, and conversation history
- [x] Add deterministic independent schema validation tests
- [x] Preserve all existing runtime behavior

### PR-002 - Workflow Manifest Schema Foundation

- [x] Define the versioned Workflow Manifest contract
- [x] Reference exact Agent Manifest IDs and versions
- [x] Preserve lifecycle versus utility Workflow semantics
- [x] Define steps, Artifact declarations, Evaluations, Approvals, transition intent, recovery, and compatibility
- [x] Add a Discovery example and deterministic structural/semantic validation
- [x] Preserve all existing runtime behavior

### PR-003 - Minimal First-Party App Package Manifest Foundation (Next)

- [ ] Define immutable package identity, Kernel compatibility, and bundled trust metadata
- [ ] Index exact Workflow and Agent definitions plus schemas, prompts, rubrics, policies, fixtures, tests, and documentation
- [ ] Define content digest and configuration overlay boundaries
- [ ] Add contract examples and deterministic validation without implementing an App registry

## Deferred Runtime Hardening

- Database-grade persistence adapters
- Knowledge Entry schema and executable Knowledge Base
- Authentication and authorization
- Observability and cost accounting
- Full workflow step execution and external tool/AI adapters

## Conditional v0.2 Follow-ups

- One read-only Tool or Knowledge capability only if required by Validation
- One opt-in real Provider adapter only after fake-provider acceptance and a security/cost review
- v0.2 adoption review before adding further platform breadth

## Later Milestones

- Discovery, Validation, and Product runtimes
- Engineering, AI, Development, UX, QA, and Deployment runtimes
- Growth, Sales, and CEO Review runtimes

Later lifecycle modules must not begin before the executable runtime contracts, planner, and first vertical slice are validated.
