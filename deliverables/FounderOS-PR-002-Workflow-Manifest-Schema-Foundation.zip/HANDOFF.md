# PR-002 Handoff: Workflow Manifest Schema Foundation

## Outcome

PR-002 is complete. FounderOS now has a strict, independently validated, versioned Workflow Manifest contract and a conceptual Discovery Workflow example. The contract remains outside the active runtime loader, so no runtime, Planner, CLI, persistence, or existing Discovery behavior changed.

## Files Changed

- `.ai/BUILD_ROADMAP.md`
- `.ai/CURRENT_SPRINT.md`
- `.ai/DECISIONS.md`
- `.ai/PROJECT_CONTEXT.md`
- `CHANGELOG.md`
- `README.md`
- `runtime/contracts/README.md`
- `runtime/contracts/agent/README.md`
- `runtime/contracts/workflow/workflow.schema.yaml`
- `runtime/contracts/workflow/README.md`
- `runtime/contracts/workflow/examples/discovery-workflow.yaml`
- `tests/test_workflow_manifest_schema.py`

## Schema Design

The Workflow Manifest uses JSON Schema Draft 2020-12 expressed as YAML and defines:

- canonical `wfl_` ULID identity and Semantic Versioning;
- explicit status and maturity;
- lifecycle and utility Workflow types;
- entry and exit state declarations;
- exact required and optional Agent references;
- required and produced Artifact declarations;
- typed, ordered process steps;
- Evaluation and human Approval requirements;
- non-authoritative state transition intent;
- bounded recovery policy; and
- Kernel and Agent Manifest compatibility bounds.

Lifecycle Workflows require a concrete exit state and transition intent. Utility Workflows require `exit_state: null` and `transition_intent: null`, making them structurally incapable of requesting a change to `Project.current_state`.

Supported step types are `human_input`, `agent_task`, `evaluation`, `approval`, `activity_request`, `artifact_creation`, and `transition_request`. Activity steps declare an RFC-0001 category but do not execute it.

## Semantic Validation

JSON Schema validates structure and conditional rules. Deterministic contract-test validation additionally checks:

- step Agent references resolve from `required_agents`;
- step Artifact inputs and outputs are declared;
- transition states match Workflow entry and exit states;
- transition Approval references resolve to required Approval declarations; and
- local definition IDs do not collide.

This validation exists only in contract tests. No runtime loader or validator was introduced.

## Discovery Example

The example models the existing deterministic Discovery conceptually:

- entry: `FOUNDER_BRIEF_COMPLETE`;
- exit: `OPPORTUNITY_SELECTED`;
- exact Product Manager and Market Research Agent references;
- required Founder Brief;
- produced Opportunity Report;
- deterministic Evaluation;
- required human Approval; and
- guarded transition intent.

It does not invoke, replace, or alter the existing Discovery implementation.

## Tests Added

Coverage includes:

- valid Discovery manifest;
- every required root field;
- empty ID;
- invalid Semantic Version;
- invalid maturity;
- invalid Workflow type;
- utility Workflow transition rejection;
- lifecycle Workflow missing-transition rejection;
- invalid step type;
- undeclared required Agent reference; and
- deterministic validation.

Validation results:

- Focused suite: `11 passed, 20 subtests passed`
- Complete suite: `106 passed, 47 subtests passed`
- Complete-suite duration: `80.85s`

## Documentation Updated

The root README, changelog, contract index, Agent Manifest documentation, project context, roadmap, sprint, and architecture decisions now describe PR-002 and the Workflow Manifest boundary.

## Intentionally Not Implemented

- Workflow loader or registry
- Workflow execution engine or coordinator
- App Package contract
- Agent selection or routing logic
- Provider calls
- Tool or Activity execution
- runtime schema adoption or migration
- CLI commands
- Web UI
- runtime behavior changes

## Remaining Risks

- The package Workflow Manifest and active v0.1 Workflow runtime schema intentionally coexist. Future adoption must define compatibility and historical resolution explicitly.
- Cross-reference checks are semantic contract rules, not runtime enforcement yet.
- Transition intent cannot grant authorization, create Approval evidence, satisfy guards, or mutate Project state.
- No package resolver currently proves referenced Agent, Artifact schema, or Evaluation rubric versions exist.

## Recommended Next PR

PR-003: Minimal First-Party App Package Manifest Foundation. Define an immutable package index over exact Workflow and Agent versions plus schemas, prompts, rubrics, policies, fixtures, tests, and documentation without implementing installation, registry, marketplace, or execution behavior.
