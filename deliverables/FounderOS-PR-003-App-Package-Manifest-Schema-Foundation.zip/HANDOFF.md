# PR-003 Handoff: App Package Manifest Schema Foundation

## Outcome

PR-003 is complete. FounderOS now has a strict, independently validated, versioned App Package Manifest and a Discovery App example. The contract remains outside the active runtime loader, so no loader, registry, installation, execution, Provider, Tool, CLI, persistence, or runtime behavior changed.

## Files Changed

- `.ai/BUILD_ROADMAP.md`
- `.ai/CURRENT_SPRINT.md`
- `.ai/DECISIONS.md`
- `.ai/PROJECT_CONTEXT.md`
- `CHANGELOG.md`
- `README.md`
- `runtime/contracts/README.md`
- `runtime/contracts/workflow/README.md`
- `runtime/contracts/app/app.schema.yaml`
- `runtime/contracts/app/README.md`
- `runtime/contracts/app/examples/discovery-app.yaml`
- `tests/test_app_manifest_schema.py`

## Schema Design

The App Package Manifest uses JSON Schema Draft 2020-12 expressed as YAML and defines:

- stable namespaced package identity such as `founderos.discovery`;
- Semantic Versioning, status, maturity, and domain;
- canonical runtime compatibility using `>=X.Y.Z <A.B.C`;
- bundled first-party publisher trust metadata;
- SHA-256 package content-digest shape;
- exact Workflow and Agent IDs, versions, and manifest paths;
- versioned Artifact schemas, prompt packs, Evaluation rules, and policy requirements;
- deterministic fixtures with SHA-256 digests;
- documentation references;
- bounded App dependencies; and
- descriptive tags.

App uses a namespaced package ID rather than a new runtime ULID prefix because it is a packaging/deployment concept, not a sixth persisted core object.

## Package Boundary

An App indexes assets only. It cannot:

- execute a Workflow;
- define or duplicate Workflow steps, recovery, Approvals, or transitions;
- mutate repositories, runtime records, Events, or Project state;
- call a Provider or invoke a Tool;
- grant authorization or capabilities;
- own memory or conversation history; or
- contain arbitrary executable plugin code.

The schema closes all objects with `additionalProperties: false`, so fields implying execution or runtime authority are rejected.

## Discovery App Example

The example packages references to:

- the Discovery Workflow;
- Product Manager and Market Research Agents;
- the Opportunity Report schema;
- a Discovery prompt pack;
- an Opportunity quality Evaluation rule;
- a Discovery capability policy requirement;
- a deterministic opportunity fixture; and
- Discovery documentation.

These are package references only. The example does not resolve, load, render, install, or execute any asset.

## Tests Added

Coverage includes:

- valid Discovery App Manifest;
- every required field;
- empty package ID;
- invalid Semantic Version;
- invalid maturity;
- missing Workflow references;
- duplicate logical Workflow identifiers;
- invalid runtime compatibility syntax;
- empty Agent index;
- invalid dependency format;
- prohibited execution/runtime-authority fields; and
- deterministic semantic validation.

Validation results:

- Focused suite: `12 passed, 25 subtests passed`
- Complete suite: `118 passed, 72 subtests passed`
- Complete-suite duration: `84.21s`

## Documentation Updated

The root README, changelog, contract index, Workflow Manifest documentation, project context, roadmap, sprint, and architecture decisions now describe PR-003 and the packaging-only App boundary.

## Intentionally Not Implemented

- App loader or resolver
- App registry
- package installation, upgrades, rollback, or removal
- marketplace or third-party trust
- package signing or verification
- canonical archive/digest computation
- Workflow execution
- prompt rendering
- Provider integration
- Tool execution
- plugin installation
- CLI commands
- runtime schema adoption or behavior changes

## Remaining Risks

- The schema validates content-digest shape but does not define or compute canonical package hashing.
- No resolver proves indexed files exist or match their declared IDs, versions, or digests.
- First-party trust is declarative only; signing, verification, and publisher identity are deferred.
- Dependency ranges are validated but no dependency solver exists.
- Prompt and Evaluation assets are referenced but do not yet have their own v0.3 package contracts.

## Recommended Next PR

PR-004: Prompt Pack Manifest Schema Foundation. Define immutable prompt-pack identity, variables, input/output schema references, safety metadata, and template asset references without implementing prompt rendering, model configuration, or Provider integration.
