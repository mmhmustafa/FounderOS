# PR-004 Handoff: Manifest Loader Foundation

## Outcome

PR-004 is complete. FounderOS now has its first v0.3 runtime capability: a stateless Manifest Loader that safely reads and validates explicit Agent, Workflow, and App YAML files. It performs no discovery, registration, reference resolution, installation, execution, Provider calls, Tool calls, CLI behavior, persistence, or Kernel mutation.

## Files Changed

- `.ai/BUILD_ROADMAP.md`
- `.ai/CURRENT_SPRINT.md`
- `.ai/DECISIONS.md`
- `.ai/PROJECT_CONTEXT.md`
- `CHANGELOG.md`
- `README.md`
- `pyproject.toml`
- `runtime/contracts/README.md`
- `runtime/contracts/agent/README.md`
- `runtime/contracts/workflow/README.md`
- `runtime/contracts/app/README.md`
- `src/founderos_runtime/manifest_loader/__init__.py`
- `src/founderos_runtime/manifest_loader/loader.py`
- `src/founderos_runtime/manifest_loader/validators.py`
- `src/founderos_runtime/manifest_loader/exceptions.py`
- `src/founderos_runtime/manifest_loader/README.md`
- `tests/test_manifest_loader.py`

## Public API

```python
from founderos_runtime.manifest_loader import (
    load_agent_manifest,
    load_workflow_manifest,
    load_app_manifest,
)
```

`ManifestLoader(contract_directory=...)` supports explicit contract roots for isolated environments and testing.

Each API:

1. reads the exact schema on every call;
2. validates the schema itself;
3. safely reads UTF-8 YAML using `yaml.safe_load`;
4. applies Draft 2020-12 structural validation;
5. applies established Workflow/App semantic invariants;
6. returns a defensive parsed dictionary; and
7. retains no cache or registry state.

## Error Model

Typed exceptions include stable `file`, `field`, and `reason` attributes:

- `ManifestFileNotFoundError`
- `ManifestReadError`
- `ManifestYamlError`
- `ManifestSchemaError`
- `ManifestValidationError`

Malformed YAML reports line and column. Invalid UTF-8 is converted to a typed YAML failure. Missing required fields and unknown fields identify the exact field rather than exposing generic parser or jsonschema exceptions.

## Architecture Decisions

- Executable loader code lives under `src/founderos_runtime/`; `runtime/contracts/` remains the single schema authority.
- Schemas and manifests are reread for every call. No caching or invalidation lifecycle is introduced.
- “Validated” includes the semantic cross-field invariants established by PR-002 and PR-003, not merely JSON Schema shape.
- Loading is independent from ContractRegistry adoption, registration, authorization, Kernel services, execution, and persistence.
- PyYAML moved from development-only to runtime dependencies because YAML parsing is now production behavior.

## Tests Added

Coverage includes:

- valid Agent, Workflow, and App manifests;
- missing files;
- malformed YAML;
- invalid UTF-8;
- invalid schemas;
- schema validation failures;
- unknown fields;
- missing required fields;
- file/field/reason error messages;
- undeclared Workflow Agent regression;
- duplicate App Workflow regression;
- fresh uncached loads; and
- deterministic error selection.

Validation results:

- Focused suite: `13 passed, 3 subtests passed`
- Complete suite: `131 passed, 75 subtests passed`
- Complete-suite duration: `82.31s`

## Documentation Updated

The root README, changelog, contract index, Agent/Workflow/App contract documentation, project context, roadmap, sprint, and architecture decisions now describe the executable loading boundary and its non-responsibilities.

## Intentionally Not Implemented

- directory discovery or manifest-kind inference
- registry or global index
- cross-package uniqueness or version resolution
- App dependency resolution
- reference-file or content-digest verification
- package installation, marketplace, or plugins
- Workflow or Agent execution
- prompt rendering
- Provider or Tool integration
- authorization enforcement
- CLI or Web UI
- state transitions, runtime records, Events, or Kernel mutation

## Known Limitations

- Default schema lookup expects the source-tree `runtime/contracts/` directory, matching current editable/local deployment. Wheel resource packaging is not defined.
- File-size and YAML-alias resource limits are not yet enforced.
- Referenced Agent, Workflow, schema, prompt, rubric, policy, fixture, and documentation files are not resolved or verified.
- App digest computation, signatures, publisher verification, and dependency solving remain deferred.
- Loading validates content but assigns no registry lifecycle or authority.

## Recommended PR-005

Bounded Manifest Discovery Foundation: discover only supported manifest filenames beneath explicit trusted roots, prevent symlink/root escapes and ambiguous kinds, order results deterministically, and delegate every file to PR-004 validation. It must remain read-only and must not register, resolve versions, install packages, execute definitions, or call the Kernel.
